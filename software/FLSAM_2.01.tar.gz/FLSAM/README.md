FLSAM
=====

The FLSAM package provides an FLR version of SAM, the State-space Assessment Model developed by Anders Nielsen, DTU-Aqua.

For details regarding SAM, please consult <http://www.stockassessment.org>. 
