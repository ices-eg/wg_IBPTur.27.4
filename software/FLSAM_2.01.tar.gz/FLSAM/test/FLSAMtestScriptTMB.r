library(FLSAM); library(TMB); library(Matrix)
source("D:/Repository/FLSAMdev/R/FLR2SAM.r")
source("D:/Repository/FLSAMdev/R/FLSAM.r")
source("D:/Repository/FLSAMdev/R/SAM2FLR.r")
source("D:/Repository/FLSAMdev/R/FLSAM.control.r")
source("D:/Repository/FLSAMdev/R/pin.r")
source("D:/Repository/FLSAMdev/R/methods_plots.r")
source("D:/Repository/FLSAMdev/R/methods.r")
source("D:/Repository/FLSAMdev/R/looi_retro.r")
source("D:/Repository/FLSAMdev/R/createAccessors.r")



#- Load data
data(NSH)
data(NSH.sam)


ctrl <- FLSAM.control(NSH,NSH.tun)
#- Update to NSH settings
ctrl@states     <- NSH.ctrl@states
ctrl@logN.vars  <- NSH.ctrl@logN.vars
ctrl@catchabilities[-grep("SCAI",rownames(NSH.ctrl@catchabilities)),] <- NSH.ctrl@catchabilities[-grep("SCAI",rownames(NSH.ctrl@catchabilities)),]
ctrl@f.vars     <- NSH.ctrl@f.vars
ctrl@obs.vars[-grep("SCAI",rownames(NSH.ctrl@catchabilities)),]   <- NSH.ctrl@obs.vars[-grep("SCAI",rownames(NSH.ctrl@obs.vars)),]
ctrl@cor.obs[] <- NA
ctrl@cor.F      <- 0
#ctrl@cor.obs.Flag <- af(c("ID","ID","AR","ID","ID"))
#ctrl@cor.obs["HERAS",] <- c(NA,1,1,1,2,2,2,2)
ctrl@srr[] <- as.integer(0)
ctrl            <- update(ctrl)

stck            <- NSH
tun             <- NSH.tun

stck.sam        <- FLSAM(stck,tun,ctrl)

retro.sam       <- retro(stock=stck,indices=tun,control=ctrl,retro=5)

#- Get data ready
res            <- FLR2SAM(stck,tun,ctrl)


tmb.exec        <- "D:/Repository/FLSAMdev/inst/cpp/sam"
pin.sam         <- NULL
map             <- NULL

type(indices[[1]]) <- "number"
type(indices[[2]]) <- "number"
type(indices[[3]]) <- "biomass"

ctrl                        <- FLSAM.control(stock,indices)
ctrl@states["catch",]       <- c(0:6,rep(7,3))
#- Set the random walk correlation flag
ctrl@cor.F[]                <- 0
#- Set the catchability parameter bindings
ctrl@catchabilities[2,]     <- c(0:3,rep(4,2),rep(NA,4))
ctrl@catchabilities[3,]     <- c(0:3,rep(4,3),rep(NA,3))  + max(ctrl@catchabilities[2,],na.rm=T) + 1
ctrl@catchabilities[4,]     <- c(0,rep(NA,9))             + max(ctrl@catchabilities[3,],na.rm=T) + 1
#- Set random walk F variances
ctrl@f.vars[1,]             <- c(rep(0,2),rep(1,2),rep(2,3),rep(3,3))
#- Set random walk N variances
ctrl@logN.vars[]            <- c(0,rep(1,9))
#- Set observation variance parameters
  #lapply(indices[1:2],function(x){dat <- x@index[,drop=T];return(apply(dat,1,sd,na.rm=T)/apply(dat,1,mean,na.rm=T))})
  #apply(catch.n(stock)[,drop=T],1,sd,na.rm=T)/apply(catch.n(stock)[,drop=T],1,mean,na.rm=T))
ctrl@obs.vars[1,]           <- c(0,1,2,2,2,2,3,3,3,3)
ctrl@obs.vars[2,]           <- c(0,1,1,1,2,2,rep(NA,4))   + max(ctrl@obs.vars[1,],na.rm=T) + 1
ctrl@obs.vars[3,]           <- c(0,1,1,2,2,2,3,rep(NA,3)) + max(ctrl@obs.vars[2,],na.rm=T) + 1
ctrl@obs.vars[4,]           <- c(0,rep(NA,9))             + max(ctrl@obs.vars[3,],na.rm=T) + 1

#- Set observation correlation structure
ctrl@cor.obs.Flag[]         <- c("ID","AR","AR","ID")
ctrl@cor.obs[1,]            <- NA
ctrl@cor.obs[2,]            <- c(rep(0,5),rep(NA,4))
ctrl@cor.obs[3,]            <- c(rep(0,6),rep(NA,3))      + max(ctrl@cor.obs[2,],na.rm=T) + 1

ctrl@simulate               <- TRUE



a <- FLSAM(stock,tun,ctrl)
stock       <- stock + a

residual.diagnostics(a)
CV.yrs <- ssb(a)$year
CV.dat <- cbind(SSB=ssb(a)$CV,
                   Fbar=fbar(a)$CV,Rec=rec(a)$CV)
matplot(CV.yrs,CV.dat,type="l",ylim=range(pretty(c(0,CV.dat))),yaxs="i",
    xlab="Year",ylab="CV of estimate",main="Uncertainties of key parameters")
legend("topleft",legend=colnames(CV.dat),lty=1:5,col=1:6,bty="n")

#Plot catchabilities values
catch <- catchabilities(a)
print(xyplot(value+ubnd+lbnd ~ age | fleet,catch,
          scale=list(alternating=FALSE,y=list(relation="free")),as.table=TRUE,
          type="l",lwd=c(2,1,1),col=c("black","grey","grey"),
          subset=fleet %in% c("HERAS"),
          main="Survey catchability parameters",ylab="Catchability",xlab="Age"))

#Plot obs_variance (weightings)
obv <- obs.var(a)
obv$str <- paste(obv$fleet,ifelse(is.na(obv$age),"",obv$age))
obv <- obv[order(obv$value),]
bp <- barplot(obv$value,ylab="Observation Variance",
       main="Observation variances by data source",col=factor(obv$fleet))
axis(1,at=bp,labels=obv$str,las=3,lty=0,mgp=c(0,0,0))
legend("topleft",levels(obv$fleet),pch=15,col=1:nlevels(obv$fleet),pt.cex=1.5)

plot(obv$value,obv$CV,xlab="Observation variance",ylab="CV of estimate",log="x",
  pch=16,col=obv$fleet,main="Observation variance vs uncertainty")
text(obv$value,obv$CV,obv$str,pos=4,cex=0.75,xpd=NA)

#Plot fishery selectivity pattern over time
sel.pat <- merge(f(a),fbar(a),
             by="year",suffixes=c(".f",".fbar"))
sel.pat$sel <- sel.pat$value.f/sel.pat$value.fbar
sel.pat$age <- as.numeric(as.character(sel.pat$age))
print(xyplot(sel ~ age|sprintf("%i's",floor((year+2)/5)*5),sel.pat,
         groups=year,type="l",as.table=TRUE,
         scale=list(alternating=FALSE),
         main="Selectivity of the Fishery by Pentad",xlab="Age",ylab="F/Fbar"))

#Plot correlation matrix
cor.plot(a)

#Bubble plot on catch and HERAS
dat <- subset(residuals(a),fleet=="catch")
xyplot(age ~ year,data=dat,cex=dat$std.res,col="black",main="Residuals by year Catch",
panel=function(...){
  lst <- list(...)
  panel.xyplot(lst$x,lst$y,pch=ifelse(lst$cex>0,1,19),col="black",cex=abs(lst$cex))
})

dat <- subset(residuals(a),fleet=="HERAS")
xyplot(age ~ year,data=dat,cex=dat$std.res,col="black",main="Residuals by year HERAS",
panel=function(...){
  lst <- list(...)
  panel.xyplot(lst$x,lst$y,pch=ifelse(lst$cex>0,1,19),col="black",cex=abs(lst$cex))
})

